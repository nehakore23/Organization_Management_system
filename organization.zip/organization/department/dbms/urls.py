from.views_old import index
from django.urls import path

from .views import (
    MasterOrganizationList,
    MasterOrganizationDetails,
    MasterUserProfileList,
    MasterUserProfileDetails,
)


urlpatterns = [
    path(
          'orgs/<int:org_id>/',
          MasterOrganizationDetails.as_view(),
          name="details",
          ),
    path(
          'orgs',
          MasterOrganizationList.as_view(),
          name="list",
          ),
    path(
        'orgs',
        MasterOrganizationDetails.as_view(),
        name='details',
        ),
    path(
          'user/<int:user_id>/',
          MasterUserProfileDetails.as_view(),
          name="details",
          ),
    path(
          'user',
          MasterUserProfileList.as_view(),
          name="list",
          ),

]
