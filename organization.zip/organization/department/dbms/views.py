from .models import (
    Organization,
    UserProfile,
)
from rest_framework.response import Response
from rest_framework.views import APIView
from .serializers import (
    Organizationserializer,
    UserProfileserializer,
)
from django.http import Http404
from django.db import transaction


class MasterOrganizationList(APIView):
    def get(self, request,*args, **kwargs):
        orgs = Organization.objects.all()
        master_organizations = Organizationserializer(
            orgs,
            many=True,
        ).data
        return Response(master_organizations)


    def post(self, request, *args, **kwargs):
       data = request.data
       with transaction.atomic():
           org_serializer = Organizationserializer(
               data=data)
           if org_serializer.is_valid(raise_exception=True):
               org = org_serializer.save()
           org_serializer_data = org_serializer.data
       return Response(org_serializer_data)


class MasterOrganizationDetails(APIView):
    def get(self, request, org_id, *args, **kwargs):
        try:
            org = Organization.objects.get(id=org_id)
        except Organization.DoesNotExist:
            raise Http404(f"Organization does not exist with this id {org_id}")
        master_organization = Organizationserializer(
            org,
        ).data
        return Response(master_organization)

    def patch(self, request, org_id, *args, **kwargs):
        data = request.data
        print("This is patch data", data)
        try:
            org = Organization.objects.get(id=org_id)
        except Organization.DoesNotExist:
            raise Http404(f"Organization does not exist with this id {org_id}")
        with transaction.atomic():
            org_serializer = Organizationserializer(
                org,
                data=data,
                partial=True
            )
            if org_serializer.is_valid(raise_exception=True):
                org = org_serializer.save()
            org_serializer_data = org_serializer.data
        return Response(org_serializer_data)


    def delete(self, request, org_id, *args, **kwargs):
        print('I am in delete')
        try:
            org = Organization.objects.get(id=org_id)
        except Organization.DoesNotExist:
            raise Http404(f"Organization does not exist with this id {org_id}")
        master_organization = Organizationserializer(
            org,
        ).data
        with transaction.atomic():
            org.delete()
        return Response(master_organization)


class MasterUserProfileList(APIView):

    def get(self, request, *args, **kwargs):
        user = UserProfile.objects.all()
        master_userprofile = UserProfileserializer(
            user,
            many=True,
        ).data
        return Response(master_userprofile)


def post(self, request, *args, **kwargs):
    data = request.data
    (auth_user, is_auth_user_created) = User.objects.get_or_create(username=data['name'])
    with transaction.atomic():
        user_serializer = UserProfileserializer(
            data=data)
        if user_serializer.is_valid(raise_exception=True):
            user = user_serializer.save()
            user.user = auth_user
            user.save()

    user_serializer_data = user_serializer.data

    return Response(user_serializer_data)

class MasterUserProfileDetails(APIView):
    def get(self, request, user_id, *args, **kwargs):
        print('I am in get')
        try:
            user = UserProfile.objects.get(id=user_id)
        except UserProfile.DoesNotExist:
            raise Http404(f"UserProfile does not exist with this id {user_id}")
        master_userprofile = UserProfileserializer(
            user,
        ).data
        return Response(master_userprofile)


    def patch(self, request, user_id, *args, **kwargs):
        data = request.data
        print("This is patch data", data)
        try:
            user = Userprofile.objects.get(id=user_id)
        except userprofile.DoesNotExist:
            raise Http404(f"Userprofile does not exist with this id {user_id}")
        with transaction.atomic():
            user_serializer = Userprofileserializer(
                user,
                data=data,
                partial=True
            )
            if user_serializer.is_valid(raise_exception=True):
                user = user_serializer.save()
            user_serializer_data = user_serializer.data
        return Response(user_serializer_data)


    def delete(self, request, user_id, *args, **kwargs):
        print('I am in delete')
        try:
            user = UserProfile.objects.get(id=user_id)
        except UserProfile.DoesNotExist:
            raise Http404(f"UserProfile does not exist with this id {user_id}")
        master_userprofile = UserProfileserializer(
            user,
        ).data
        with transaction.atomic():
            users.delete()
        return Response(master_userprofile)

