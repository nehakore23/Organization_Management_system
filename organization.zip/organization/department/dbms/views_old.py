#from django.shortcuts import render
from django.http import HttpResponse
from .models import Organization


# Create your views here.
def index(request):
    orgs_list = []
    orgs = Organization.objects.all()
    for org in orgs:
        org_dict = org.__dict__
        del org_dict["_state"]
        print(org_dict)
        orgs_list.append(org_dict)
    return HttpResponse(orgs_list)
